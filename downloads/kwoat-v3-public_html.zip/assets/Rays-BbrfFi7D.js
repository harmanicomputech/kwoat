import{n as e,s as t,v as n,y as r}from"./index-DtPRzyV4.js";var i=r(n(),1),a=t(),o=`attribute vec2 p; void main(){ gl_Position = vec4(p,0.,1.); }`,s=`
precision highp float;
uniform vec2 uRes; uniform float uTime; uniform vec2 uFocal; uniform vec2 uMouse; uniform float uIntensity; uniform float uSpread;

float hash(vec2 p){ return fract(sin(dot(p, vec2(41.3, 289.1))) * 43758.5453); }
float noise(vec2 p){
  vec2 i = floor(p), f = fract(p); vec2 u = f*f*(3.-2.*f);
  return mix(mix(hash(i), hash(i+vec2(1,0)), u.x), mix(hash(i+vec2(0,1)), hash(i+vec2(1,1)), u.x), u.y);
}

// distance from p to segment a-b, and position t along it
vec2 seg(vec2 p, vec2 a, vec2 b){
  vec2 pa = p - a, ba = b - a;
  float t = clamp(dot(pa, ba) / dot(ba, ba), 0., 1.);
  return vec2(length(pa - ba * t), t);
}

void main(){
  float aspect = uRes.x / uRes.y;
  vec2 uv = gl_FragCoord.xy / uRes.y;           // y in 0..1, x in 0..aspect
  vec2 focal = vec2(uFocal.x * aspect, uFocal.y) + uMouse * vec2(.04, .02);
  float tilt = uMouse.x * .06;

  vec3 col = vec3(0.);
  // origins mirror the logo: wide fan above the viewport
  float xs[5];
  xs[0] = -1.; xs[1] = -.5; xs[2] = 0.; xs[3] = .5; xs[4] = 1.;
  for (int i = 0; i < 5; i++) {
    float fi = float(i);
    float spread = xs[i] * uSpread * aspect * .5;
    vec2 origin = vec2(focal.x + spread + tilt, 1.18 + abs(xs[i]) * -.04);
    vec2 d = seg(uv, origin, focal);
    float t = d.y;
    // beam is wide at the top, a needle at the focal point (like the logo's triangles)
    float w = mix(.022, .0012, pow(t, .9)) * (i == 2 ? .75 : 1.);
    float core = smoothstep(w, 0., d.x);
    float halo = exp(-d.x / (w * 5.)) * .35;
    // light travelling down the beam
    float flow = noise(vec2(t * 7. - uTime * (.55 + fi * .07), fi * 3.1));
    flow = .55 + .45 * flow;
    float fade = smoothstep(0., .25, t) * (1. - smoothstep(.985, 1., t) * .2);
    float b = (core + halo) * flow * fade;
    vec3 tint = mix(vec3(.49, .23, .93), vec3(.77, .71, .99), core);
    col += tint * b;
  }
  // focal bloom
  float fd = length(uv - focal);
  col += vec3(.55, .36, .98) * exp(-fd * 9.) * .55;
  col += vec3(.95, .92, 1.) * exp(-fd * 42.) * .5;
  // wide atmospheric wash from above
  col += vec3(.29, .12, .62) * smoothstep(.9, 0., length((uv - vec2(focal.x, 1.1)) * vec2(.6, 1.))) * .22;
  // dust motes caught in the light
  vec2 g = uv * vec2(90., 90.) + vec2(0., uTime * 1.2);
  vec2 gi = floor(g);
  float h = hash(gi);
  float mote = step(.985, h) * smoothstep(.35, 0., length(fract(g) - .5));
  col += vec3(.8, .75, 1.) * mote * clamp(length(col) * 1.5, 0., 1.) * (.5 + .5 * sin(uTime * 2. + h * 40.));

  col *= uIntensity;
  // gentle tone map so overlaps never clip harshly
  col = 1. - exp(-col * 1.6);
  gl_FragColor = vec4(col, 1.);
}`;function c({focal:t=[.5,.42],intensity:n=1,spread:r=1,className:c=``}){let l=(0,i.useRef)(null),u=(0,i.useRef)({focal:t,intensity:n,spread:r});return u.current={focal:t,intensity:n,spread:r},(0,i.useEffect)(()=>{let t=l.current,n=t.getContext(`webgl`,{antialias:!1,alpha:!1});if(!n){t.classList.add(`no-webgl`);return}let r=(e,t)=>{let r=n.createShader(e);return n.shaderSource(r,t),n.compileShader(r),r},i=n.createProgram();n.attachShader(i,r(n.VERTEX_SHADER,o)),n.attachShader(i,r(n.FRAGMENT_SHADER,s)),n.linkProgram(i),n.useProgram(i),n.bindBuffer(n.ARRAY_BUFFER,n.createBuffer()),n.bufferData(n.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),n.STATIC_DRAW);let a=n.getAttribLocation(i,`p`);n.enableVertexAttribArray(a),n.vertexAttribPointer(a,2,n.FLOAT,!1,0,0);let c=e=>n.getUniformLocation(i,e),d=c(`uRes`),f=c(`uTime`),p=c(`uFocal`),m=c(`uMouse`),h=c(`uIntensity`),g=c(`uSpread`),_=Math.min(window.devicePixelRatio,1.5)*.75,v=()=>{t.width=Math.max(1,Math.round(t.clientWidth*_)),t.height=Math.max(1,Math.round(t.clientHeight*_)),n.viewport(0,0,t.width,t.height),n.uniform2f(d,t.width,t.height)},y=new ResizeObserver(v);y.observe(t),v();let b={x:0,y:0,tx:0,ty:0},x=e=>{b.tx=e.clientX/window.innerWidth*2-1,b.ty=-(e.clientY/window.innerHeight*2-1)};window.addEventListener(`pointermove`,x);let S=!0,C=new IntersectionObserver(([e])=>S=e.isIntersecting);C.observe(t);let w=e(),T=performance.now(),E=0,D=()=>{if(E=requestAnimationFrame(D),!S)return;b.x+=(b.tx-b.x)*.04,b.y+=(b.ty-b.y)*.04;let{focal:e,intensity:t,spread:r}=u.current;n.uniform1f(f,w?4:(performance.now()-T)/1e3),n.uniform2f(p,e[0],e[1]),n.uniform2f(m,b.x,b.y),n.uniform1f(h,t),n.uniform1f(g,r),n.drawArrays(n.TRIANGLE_STRIP,0,4)};return D(),()=>{cancelAnimationFrame(E),y.disconnect(),C.disconnect(),window.removeEventListener(`pointermove`,x),n.getExtension(`WEBGL_lose_context`)?.loseContext()}},[]),(0,a.jsx)(`canvas`,{ref:l,className:`rays ${c}`,"aria-hidden":!0})}export{c as t};