import{f as e}from"./index-DOFGWfla.js";import{a as t,i as n,t as r}from"./ui-BWe3q_Nk.js";var i=e();function a(){return(0,i.jsxs)(`div`,{className:`nf`,children:[(0,i.jsx)(`div`,{className:`nf-blob`,"aria-hidden":!0}),(0,i.jsxs)(`div`,{className:`nf-in`,children:[(0,i.jsx)(t,{size:56,className:`nf-mark`}),(0,i.jsx)(`h1`,{className:`display h-hero`,children:(0,i.jsx)(`span`,{className:`grad-text`,children:`404`})}),(0,i.jsx)(`p`,{className:`lede`,children:`Even the best router can’t find this page.`}),(0,i.jsxs)(n,{to:`/`,className:`btn btn-primary btn-lg`,children:[`Back home `,(0,i.jsx)(r,{})]})]}),(0,i.jsx)(`style`,{children:`
        .nf{position:relative;min-height:100svh;display:grid;place-items:center;overflow:hidden;padding:24px}
        .nf-blob{position:absolute;width:70vmax;height:70vmax;border-radius:50%;background:conic-gradient(from 0deg,#c4b5fd,#f9a8d4,#fed7aa,#bae6fd,#c4b5fd);filter:blur(90px);opacity:.55;animation:rot 18s linear infinite}
        .nf-in{position:relative;display:grid;justify-items:center;gap:22px;text-align:center}
        .nf-mark{color:var(--violet);animation:floaty 4s ease-in-out infinite}
        @keyframes floaty{50%{transform:translateY(-14px) rotate(-6deg)}}
        .nf .lede{text-align:center}
      `})]})}export{a as default};