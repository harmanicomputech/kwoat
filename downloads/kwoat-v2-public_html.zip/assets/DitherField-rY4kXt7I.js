import{b as e,c as t,n,y as r}from"./index-BZCUmPxc.js";var i=e(r(),1),a=t(),o=`attribute vec2 p; void main(){ gl_Position = vec4(p,0.,1.); }`,s=`
precision highp float;
uniform vec2 uRes; uniform float uTime; uniform vec2 uMouse; uniform float uCell;
uniform vec3 uInk; uniform vec3 uPaper; uniform vec3 uSignal; uniform float uDensity; uniform float uScroll; uniform float uSide;

float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7))) * 43758.5453); }
float noise(vec2 p){
  vec2 i = floor(p), f = fract(p);
  vec2 u = f*f*(3.-2.*f);
  return mix(mix(hash(i), hash(i+vec2(1,0)), u.x), mix(hash(i+vec2(0,1)), hash(i+vec2(1,1)), u.x), u.y);
}
float fbm(vec2 p){
  float v = 0., a = .5;
  for(int i=0;i<5;i++){ v += a*noise(p); p = p*2.03 + vec2(1.7,9.2); a *= .5; }
  return v;
}
float bayer(vec2 c){
  // 8x8 Bayer threshold built from the 2x2 recursion
  vec2 a = floor(mod(c, 8.));
  float v = 0.;
  float s = 1.;
  for(int i=0;i<3;i++){
    vec2 b = floor(mod(a / s, 2.));
    v += (2.*b.x + 3.*b.y - 4.*b.x*b.y) * pow(4., float(2-i));
    s *= 2.;
  }
  return (v + .5) / 64.;
}
void main(){
  vec2 frag = gl_FragCoord.xy;
  vec2 cell = floor(frag / uCell);
  vec2 uv = (cell * uCell) / uRes.y;
  vec2 m = uMouse * vec2(uRes.x/uRes.y, 1.);
  float d = distance(uv, m);
  float lens = smoothstep(.32, 0., d);
  vec2 q = uv * 2.2 + vec2(0., uScroll*1.5);
  q += (uv - m) * lens * -.6;
  float t = uTime * .06;
  float n = fbm(q + vec2(fbm(q + t*1.3), fbm(q - t)) * 1.6 + t);
  // fade the field toward the left so headline copy stays readable
  float x = gl_FragCoord.x / uRes.x;
  float side = smoothstep(.3, .95, x) * uSide + (1. - uSide);
  float top = smoothstep(1., .82, gl_FragCoord.y / uRes.y);
  float lum = clamp((n - .44) * 2.4, 0., 1.) * side * top * uDensity;
  lum = max(lum, lens * .38 * uDensity * mix(.5, 1., side));
  float on = step(1. - lum, bayer(cell));
  vec3 inkCol = mix(uInk, uSignal, smoothstep(.16, .02, d));
  vec3 col = mix(uPaper, inkCol, on);
  gl_FragColor = vec4(col, 1.);
}`;function c(e){let t=document.createElement(`canvas`).getContext(`2d`);t.fillStyle=e;let n=t.fillStyle,r=parseInt(n.slice(1),16);return[(r>>16&255)/255,(r>>8&255)/255,(r&255)/255]}function l({density:e=1,cell:t=3,className:r=``,fadeLeft:l=!0}){let u=(0,i.useRef)(null);return(0,i.useEffect)(()=>{let r=u.current,i=r.getContext(`webgl`,{antialias:!1,premultipliedAlpha:!1});if(!i){r.classList.add(`no-webgl`);return}let a=(e,t)=>{let n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n},d=i.createProgram();i.attachShader(d,a(i.VERTEX_SHADER,o)),i.attachShader(d,a(i.FRAGMENT_SHADER,s)),i.linkProgram(d),i.useProgram(d);let f=i.createBuffer();i.bindBuffer(i.ARRAY_BUFFER,f),i.bufferData(i.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),i.STATIC_DRAW);let p=i.getAttribLocation(d,`p`);i.enableVertexAttribArray(p),i.vertexAttribPointer(p,2,i.FLOAT,!1,0,0);let m=e=>i.getUniformLocation(d,e),h=m(`uRes`),g=m(`uTime`),_=m(`uMouse`),v=m(`uCell`),y=m(`uInk`),b=m(`uPaper`),x=m(`uSignal`),S=m(`uDensity`),C=m(`uScroll`),w=m(`uSide`),T=()=>{let e=getComputedStyle(document.documentElement);i.uniform3fv(y,c(e.getPropertyValue(`--ink`).trim())),i.uniform3fv(b,c(e.getPropertyValue(`--paper`).trim())),i.uniform3fv(x,c(e.getPropertyValue(`--signal`).trim()))};T();let E=new MutationObserver(T);E.observe(document.documentElement,{attributes:!0,attributeFilter:[`data-theme`]});let D=Math.min(window.devicePixelRatio,2),O=()=>{r.width=r.clientWidth*D,r.height=r.clientHeight*D,i.viewport(0,0,r.width,r.height),i.uniform2f(h,r.width,r.height),i.uniform1f(v,t*D)},k=new ResizeObserver(O);k.observe(r),O(),i.uniform1f(S,e),i.uniform1f(w,+!!l);let A={x:.75,y:.5,tx:.75,ty:.5},j=e=>{let t=r.getBoundingClientRect();A.tx=(e.clientX-t.left)/t.width,A.ty=1-(e.clientY-t.top)/t.height};window.addEventListener(`pointermove`,j);let M=!0,N=new IntersectionObserver(([e])=>M=e.isIntersecting);N.observe(r);let P=n(),F=performance.now(),I=0,L=()=>{if(I=requestAnimationFrame(L),!M)return;A.x+=(A.tx-A.x)*.08,A.y+=(A.ty-A.y)*.08;let e=r.getBoundingClientRect();i.uniform1f(g,P?12:(performance.now()-F)/1e3),i.uniform2f(_,A.x,A.y),i.uniform1f(C,Math.max(0,-e.top/Math.max(1,e.height))),i.drawArrays(i.TRIANGLE_STRIP,0,4)};return L(),()=>{cancelAnimationFrame(I),k.disconnect(),N.disconnect(),E.disconnect(),window.removeEventListener(`pointermove`,j),i.getExtension(`WEBGL_lose_context`)?.loseContext()}},[e,t,l]),(0,a.jsx)(`canvas`,{ref:u,className:`dither ${r}`,"aria-hidden":!0})}export{l as t};